"use client"

import { useAuth } from "@/lib/auth-context"
import { useRouter, useParams } from "next/navigation"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, Mic, MicOff, Video, VideoOff, MessageSquare, Send } from "lucide-react"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { DataStore } from "@/lib/data-store"

export default function PracticeSession() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const params = useParams()
  const [isRecording, setIsRecording] = useState(false)
  const [isVideoOn, setIsVideoOn] = useState(true)
  const [message, setMessage] = useState("")
  const [conversation, setConversation] = useState<{ role: "student" | "avatar"; text: string }[]>([])
  const [sessionProgress, setSessionProgress] = useState(0)
  const [currentPhase, setCurrentPhase] = useState("Introduction")
  const [scenario, setScenario] = useState<any>(null)

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "student")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    // Load scenario details
    const scenarioData = DataStore.getScenarioById(params.id as string)
    setScenario(scenarioData)

    setConversation([
      {
        role: "avatar",
        text: "Hello Doctor. Thank you for seeing me today. I've been feeling quite worried and I really need to talk to someone about what's been going on.",
      },
    ])
  }, [params.id])

  const handleSendMessage = () => {
    if (!message.trim()) return

    // Add student message
    setConversation([...conversation, { role: "student", text: message }])

    setTimeout(() => {
      const responses = [
        "I see... yes, that's exactly how I've been feeling.",
        "It's been going on for about two weeks now, Doctor.",
        "I'm really worried about this. What do you think it could be?",
        "Thank you for listening, Doctor. That helps me feel a bit better.",
        "Should I be concerned about this? I've been losing sleep over it.",
        "My family has been asking me about it too. They're worried.",
      ]
      const randomResponse = responses[Math.floor(Math.random() * responses.length)]
      setConversation((prev) => [...prev, { role: "avatar", text: randomResponse }])

      // Update progress
      setSessionProgress((prev) => Math.min(prev + 15, 100))

      // Update phase based on progress
      if (sessionProgress >= 75) setCurrentPhase("Conclusion")
      else if (sessionProgress >= 40) setCurrentPhase("Discussion")
    }, 1500)

    setMessage("")
  }

  const handleEndSession = () => {
    if (user) {
      const sessionData = {
        id: Date.now().toString(),
        studentId: user.id,
        scenarioId: params.id as string,
        date: new Date().toISOString().split("T")[0],
        duration: Math.floor(Math.random() * 10) + 10, // Mock duration 10-20 min
        overallScore: Math.floor(Math.random() * 20) + 75, // Mock score 75-95
        skillScores: [
          { skill: "Empathy", score: Math.floor(Math.random() * 20) + 80 },
          { skill: "Clear Communication", score: Math.floor(Math.random() * 20) + 75 },
          { skill: "Active Listening", score: Math.floor(Math.random() * 20) + 80 },
          { skill: "Professional Demeanor", score: Math.floor(Math.random() * 20) + 85 },
          { skill: "Body Language", score: Math.floor(Math.random() * 20) + 75 },
          { skill: "Facial Expression", score: Math.floor(Math.random() * 20) + 80 },
          { skill: "Voice Tone", score: Math.floor(Math.random() * 20) + 78 },
        ],
        strengths: [
          "Excellent use of empathetic language",
          "Good pacing and pauses",
          "Clear explanation of complex information",
          "Appropriate body language and posture",
          "Warm and reassuring facial expressions",
          "Calm and professional voice tone",
        ],
        improvements: [
          "Consider asking more open-ended questions",
          "Allow more time for patient to process information",
          "Maintain more consistent eye contact",
          "Vary voice tone to emphasize key points",
        ],
      }
      DataStore.savePracticeSession(sessionData)
    }
    router.push("/student/practice/results")
  }

  if (isLoading || !user || !scenario) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto flex items-center justify-between px-6 py-4">
          <Button variant="ghost" onClick={() => router.push("/student/dashboard")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
          <div className="flex items-center gap-4">
            <Badge variant="secondary">{currentPhase}</Badge>
            <div className="w-48">
              <Progress value={sessionProgress} className="h-2" />
            </div>
            <span className="text-sm text-muted-foreground">{sessionProgress}%</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* AI Avatar Video Section */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>{scenario.title} - Practice Session</CardTitle>
                <CardDescription>
                  You are the doctor. Interact with the AI patient to practice your communication skills
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Avatar Display */}
                <div className="relative aspect-video overflow-hidden rounded-lg bg-muted">
                  <div className="flex h-full items-center justify-center">
                    <div className="text-center">
                      <Avatar className="mx-auto h-32 w-32">
                        <AvatarImage src="/patient-avatar.jpg" />
                        <AvatarFallback>SC</AvatarFallback>
                      </Avatar>
                      <p className="mt-4 text-lg font-medium text-foreground">Sarah Chen</p>
                      <p className="text-sm text-muted-foreground">Patient (AI Avatar)</p>
                    </div>
                  </div>
                  {/* Video Controls Overlay */}
                  <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 gap-2">
                    <Button
                      variant={isRecording ? "destructive" : "secondary"}
                      size="icon"
                      onClick={() => setIsRecording(!isRecording)}
                    >
                      {isRecording ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
                    </Button>
                    <Button
                      variant={isVideoOn ? "secondary" : "destructive"}
                      size="icon"
                      onClick={() => setIsVideoOn(!isVideoOn)}
                    >
                      {isVideoOn ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                {/* Conversation History */}
                <Card className="border-2">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <MessageSquare className="h-4 w-4" />
                      Conversation
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4 max-h-64 space-y-3 overflow-y-auto">
                      {conversation.map((msg, index) => (
                        <div key={index} className={`flex ${msg.role === "student" ? "justify-end" : "justify-start"}`}>
                          <div
                            className={`max-w-[80%] rounded-lg p-3 ${
                              msg.role === "student" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"
                            }`}
                          >
                            <p className="text-sm">{msg.text}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Message Input */}
                    <div className="flex gap-2">
                      <Textarea
                        placeholder="Type your response..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && !e.shiftKey) {
                            e.preventDefault()
                            handleSendMessage()
                          }
                        }}
                        rows={2}
                        className="resize-none"
                      />
                      <Button onClick={handleSendMessage} size="icon" className="self-end">
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Button variant="destructive" className="w-full" onClick={handleEndSession}>
                  End Session & View Results
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Scenario Info & Tips */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Scenario Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="mb-2 text-sm font-medium text-muted-foreground">Description</h4>
                  <p className="text-sm text-foreground">{scenario.description}</p>
                </div>
                <div>
                  <h4 className="mb-2 text-sm font-medium text-muted-foreground">Learning Objectives</h4>
                  <ul className="space-y-1 text-sm text-foreground">
                    {scenario.objectives.map((objective: string, index: number) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>{objective}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tips for Success</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Introduce yourself and establish rapport</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Use open-ended questions to understand concerns</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Show empathy and validate patient feelings</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Avoid medical jargon, use plain language</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">✓</span>
                    <span>Provide clear explanations and next steps</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
