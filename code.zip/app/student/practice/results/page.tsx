"use client"

import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Trophy, TrendingUp, Target, Home, RotateCcw } from "lucide-react"
import { DataStore, type PracticeSession } from "@/lib/data-store"

export default function PracticeResults() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [sessionData, setSessionData] = useState<PracticeSession | null>(null)
  const [scenarioTitle, setScenarioTitle] = useState<string>("")

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "student")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    if (user) {
      const sessions = DataStore.getPracticeSessionsByStudent(user.id)
      if (sessions.length > 0) {
        // Get the most recent session
        const latestSession = sessions[sessions.length - 1]
        setSessionData(latestSession)

        // Get scenario title
        const scenario = DataStore.getScenarioById(latestSession.scenarioId)
        if (scenario) {
          setScenarioTitle(scenario.title)
        }
      }
    }
  }, [user])

  if (isLoading || !user || !sessionData) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-lg">Loading results...</div>
      </div>
    )
  }

  const overallScore = sessionData.overallScore
  const skillScores = sessionData.skillScores
  const strengths = sessionData.strengths
  const improvements = sessionData.improvements

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
              <span className="text-lg font-bold text-primary-foreground">MC</span>
            </div>
            <div>
              <h1 className="text-xl font-semibold text-foreground">Practice Session Results</h1>
              <p className="text-sm text-muted-foreground">{scenarioTitle || "Practice Session"}</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        <div className="mx-auto max-w-4xl space-y-6">
          {/* Overall Score */}
          <Card className="border-2 border-primary">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 flex h-24 w-24 items-center justify-center rounded-full bg-primary">
                <Trophy className="h-12 w-12 text-primary-foreground" />
              </div>
              <CardTitle className="text-3xl">Great Job!</CardTitle>
              <CardDescription>You completed the practice session</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="mb-2 text-6xl font-bold text-primary">{overallScore}%</div>
              <p className="text-lg text-muted-foreground">Overall Score</p>
              <Badge className="mt-4" variant="secondary">
                <TrendingUp className="mr-1 h-3 w-3" />
                Session Duration: {sessionData.duration} min
              </Badge>
            </CardContent>
          </Card>

          {/* Skill Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Skill Breakdown
              </CardTitle>
              <CardDescription>Your performance across different communication skills</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Verbal Communication Skills */}
                <div className="space-y-3">
                  <h4 className="text-sm font-semibold text-muted-foreground">Verbal Communication</h4>
                  {skillScores
                    .filter((item) =>
                      ["Empathy", "Clear Communication", "Active Listening", "Professional Demeanor"].includes(
                        item.skill,
                      ),
                    )
                    .map((item) => (
                      <div key={item.skill} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-foreground">{item.skill}</span>
                          <span className="text-lg font-semibold text-primary">{item.score}%</span>
                        </div>
                        <Progress value={item.score} className="h-2" />
                      </div>
                    ))}
                </div>

                {/* Non-Verbal Communication Skills */}
                <div className="space-y-3">
                  <h4 className="text-sm font-semibold text-muted-foreground">Non-Verbal Communication</h4>
                  {skillScores
                    .filter((item) => ["Body Language", "Facial Expression", "Voice Tone"].includes(item.skill))
                    .map((item) => (
                      <div key={item.skill} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-foreground">{item.skill}</span>
                          <span className="text-lg font-semibold text-primary">{item.score}%</span>
                        </div>
                        <Progress value={item.score} className="h-2" />
                      </div>
                    ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Strengths & Improvements */}
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-green-600">Strengths</CardTitle>
                <CardDescription>What you did well</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {strengths.map((strength, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm">
                      <span className="text-green-600">✓</span>
                      <span className="text-foreground">{strength}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-yellow-600">Areas for Improvement</CardTitle>
                <CardDescription>Focus on these for next time</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {improvements.map((improvement, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm">
                      <span className="text-yellow-600">→</span>
                      <span className="text-foreground">{improvement}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <Button className="flex-1" onClick={() => router.push("/student/dashboard")}>
              <Home className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
            <Button
              variant="outline"
              className="flex-1 bg-transparent"
              onClick={() => router.push(`/student/practice/${sessionData.scenarioId}`)}
            >
              <RotateCcw className="mr-2 h-4 w-4" />
              Practice Again
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}
