import { LoginForm } from "@/components/login-form"
import { Activity } from "lucide-react"

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
              <Activity className="w-7 h-7 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-semibold text-foreground">MedComm AI</h1>
          </div>
          <p className="text-muted-foreground text-balance">AI-Powered Communication Skills Analyzer</p>
        </div>
        <LoginForm />
      </div>
    </div>
  )
}
