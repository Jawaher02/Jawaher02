import { SignupForm } from "@/components/signup-form"
import { Activity } from "lucide-react"
import Link from "next/link"

export default function SignupPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
              <Activity className="w-7 h-7 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-semibold text-foreground">MedComm AI</h1>
          </div>
          <p className="text-muted-foreground text-balance">Create your account to get started</p>
        </div>
        <SignupForm />
        <div className="text-center mt-4">
          <Link href="/login" className="text-sm text-muted-foreground hover:text-foreground">
            Already have an account? <span className="text-primary">Sign in</span>
          </Link>
        </div>
      </div>
    </div>
  )
}
