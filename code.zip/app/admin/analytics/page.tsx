"use client"

import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Users, TrendingUp, BookOpen, Award } from "lucide-react"
import { DataStore } from "@/lib/data-store"
import { AnalyticsChart } from "@/components/shared/analytics-chart"

export default function AdminAnalytics() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [analyticsData, setAnalyticsData] = useState<any>(null)

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "admin")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    if (user?.role === "admin") {
      // Calculate system-wide analytics
      const allSessions = DataStore.getAllPracticeSessions()
      const scenarios = DataStore.getScenarios()
      const users = JSON.parse(localStorage.getItem("medcomm_users") || "[]")

      // Sessions over time (last 7 days)
      const last7Days = Array.from({ length: 7 }, (_, i) => {
        const date = new Date()
        date.setDate(date.getDate() - (6 - i))
        return date.toISOString().split("T")[0]
      })

      const sessionsOverTime = last7Days.map((date) => ({
        date: date.slice(5),
        sessions: allSessions.filter((s) => s.date === date).length,
      }))

      // Average scores by scenario
      const scenarioScores = scenarios.map((scenario) => {
        const scenarioSessions = allSessions.filter((s) => s.scenarioId === scenario.id)
        const avgScore =
          scenarioSessions.length > 0
            ? Math.round(scenarioSessions.reduce((sum, s) => sum + s.overallScore, 0) / scenarioSessions.length)
            : 0

        return {
          scenario: scenario.title.slice(0, 15),
          score: avgScore,
        }
      })

      setAnalyticsData({
        totalUsers: users.length,
        totalSessions: allSessions.length,
        avgSystemScore: Math.round(allSessions.reduce((sum, s) => sum + s.overallScore, 0) / (allSessions.length || 1)),
        activeStudents: users.filter((u: any) => u.role === "student").length,
        sessionsOverTime,
        scenarioScores,
      })
    }
  }, [user])

  if (isLoading || !user || !analyticsData) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto flex items-center justify-between px-6 py-4">
          <Button variant="ghost" onClick={() => router.push("/admin/dashboard")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
          <h1 className="text-xl font-semibold">System Analytics</h1>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <div className="mb-8 grid gap-6 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{analyticsData.totalUsers}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Sessions</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{analyticsData.totalSessions}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Avg System Score</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{analyticsData.avgSystemScore}%</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Students</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{analyticsData.activeStudents}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <AnalyticsChart
            title="Practice Sessions Over Time"
            description="Number of practice sessions in the last 7 days"
            data={analyticsData.sessionsOverTime}
            type="line"
            dataKey="sessions"
            xAxisKey="date"
          />

          <AnalyticsChart
            title="Average Scores by Scenario"
            description="Performance across different scenarios"
            data={analyticsData.scenarioScores}
            type="bar"
            dataKey="score"
            xAxisKey="scenario"
          />
        </div>
      </main>
    </div>
  )
}
