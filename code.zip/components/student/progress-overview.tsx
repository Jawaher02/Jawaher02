"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Trophy, TrendingUp, Target, Calendar } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { DataStore } from "@/lib/data-store"

interface SkillProgress {
  skill: string
  score: number
  sessions: number
  trend: "up" | "down" | "stable"
}

interface RecentSession {
  id: string
  scenario: string
  date: string
  score: number
  duration: string
}

export function ProgressOverview() {
  const { user } = useAuth()
  const [skills, setSkills] = useState<SkillProgress[]>([])
  const [recentSessions, setRecentSessions] = useState<RecentSession[]>([])
  const [stats, setStats] = useState({ totalTime: 0, completed: 0, total: 0, mastered: 0 })

  useEffect(() => {
    if (!user) return

    const progress = DataStore.calculateStudentProgress(user.id)
    const sessions = DataStore.getPracticeSessionsByStudent(user.id)
    const scenarios = DataStore.getScenarios()

    setSkills(progress.skillProgress)

    // Calculate recent sessions
    const recent = sessions
      .slice(-4)
      .reverse()
      .map((session) => {
        const scenario = DataStore.getScenarioById(session.scenarioId)
        return {
          id: session.id,
          scenario: scenario?.title || "Unknown Scenario",
          date: session.date,
          score: session.overallScore,
          duration: `${session.duration} min`,
        }
      })
    setRecentSessions(recent)

    // Calculate stats
    const totalTime = sessions.reduce((sum, s) => sum + s.duration, 0) / 60
    const mastered = progress.skillProgress.filter((s) => s.score >= 85).length

    setStats({
      totalTime: Math.round(totalTime * 10) / 10,
      completed: progress.completedScenarios.length,
      total: scenarios.length,
      mastered,
    })
  }, [user])

  const getScoreColor = (score: number) => {
    if (score >= 85) return "text-green-600"
    if (score >= 70) return "text-yellow-600"
    return "text-red-600"
  }

  const getTrendIcon = (trend: string) => {
    if (trend === "up") return <TrendingUp className="h-4 w-4 text-green-600" />
    if (trend === "down") return <TrendingUp className="h-4 w-4 rotate-180 text-red-600" />
    return <div className="h-4 w-4" />
  }

  return (
    <div className="space-y-6">
      {/* Overall Stats */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Practice Time</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.totalTime} hours</div>
            <p className="text-xs text-muted-foreground">Across {recentSessions.length} sessions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Scenarios Completed</CardTitle>
            <Trophy className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {stats.completed} / {stats.total}
            </div>
            <p className="text-xs text-muted-foreground">
              {Math.round((stats.completed / stats.total) * 100)}% completion rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Skills Mastered</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {stats.mastered} / {skills.length}
            </div>
            <p className="text-xs text-muted-foreground">
              {skills.length > 0 ? Math.round((stats.mastered / skills.length) * 100) : 0}% mastery rate
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Skills Progress */}
      {skills.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Skills Progress</CardTitle>
            <CardDescription>Track your improvement across different communication skills</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {skills.map((skill) => (
                <div key={skill.skill} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-foreground">{skill.skill}</span>
                      {getTrendIcon(skill.trend)}
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-muted-foreground">{skill.sessions} sessions</span>
                      <span className={`text-lg font-semibold ${getScoreColor(skill.score)}`}>{skill.score}%</span>
                    </div>
                  </div>
                  <Progress value={skill.score} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Sessions */}
      {recentSessions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Practice Sessions</CardTitle>
            <CardDescription>Your latest practice activities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentSessions.map((session) => (
                <div key={session.id} className="flex items-center justify-between rounded-lg border p-4">
                  <div className="space-y-1">
                    <p className="font-medium text-foreground">{session.scenario}</p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>{session.date}</span>
                      <span>{session.duration}</span>
                    </div>
                  </div>
                  <Badge className={`${getScoreColor(session.score)} text-lg font-semibold`}>{session.score}%</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {recentSessions.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">No practice sessions yet. Start practicing to see your progress!</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
