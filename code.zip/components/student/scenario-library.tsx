"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, Play, Clock, Target } from "lucide-react"
import { useRouter } from "next/navigation"

interface Scenario {
  id: string
  title: string
  category: string
  difficulty: "beginner" | "intermediate" | "advanced"
  description: string
  duration: string
  objectives: string[]
  completed: boolean
  lastScore?: number
}

export function ScenarioLibrary() {
  const router = useRouter()
  const [scenarios, setScenarios] = useState<Scenario[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [filterDifficulty, setFilterDifficulty] = useState<string>("all")

  useEffect(() => {
    // Load mock scenarios
    const mockScenarios: Scenario[] = [
      {
        id: "1",
        title: "Breaking Bad News",
        category: "Patient Communication",
        difficulty: "advanced",
        description: "Practice delivering difficult news to patients with empathy and professionalism",
        duration: "15-20 min",
        objectives: ["Demonstrate empathy", "Use clear language", "Allow time for questions"],
        completed: true,
        lastScore: 88,
      },
      {
        id: "2",
        title: "Taking Medical History",
        category: "Clinical Skills",
        difficulty: "beginner",
        description: "Conduct a comprehensive patient history interview using proper techniques",
        duration: "10-15 min",
        objectives: ["Ask open-ended questions", "Active listening", "Document accurately"],
        completed: true,
        lastScore: 92,
      },
      {
        id: "3",
        title: "Informed Consent Discussion",
        category: "Ethics",
        difficulty: "intermediate",
        description: "Explain medical procedures and obtain informed consent from patients",
        duration: "12-18 min",
        objectives: ["Explain risks and benefits", "Ensure understanding", "Respect autonomy"],
        completed: false,
      },
      {
        id: "4",
        title: "Handling Angry Patients",
        category: "Conflict Resolution",
        difficulty: "advanced",
        description: "De-escalate tense situations and address patient concerns professionally",
        duration: "15-20 min",
        objectives: ["Stay calm", "Active listening", "Find solutions", "Maintain boundaries"],
        completed: false,
      },
      {
        id: "5",
        title: "Explaining Diagnosis",
        category: "Patient Communication",
        difficulty: "intermediate",
        description: "Communicate complex medical information in patient-friendly language",
        duration: "10-15 min",
        objectives: ["Use simple language", "Check understanding", "Provide resources"],
        completed: true,
        lastScore: 78,
      },
      {
        id: "6",
        title: "Cultural Sensitivity",
        category: "Diversity & Inclusion",
        difficulty: "intermediate",
        description: "Navigate cultural differences in patient care with respect and awareness",
        duration: "12-15 min",
        objectives: ["Show cultural awareness", "Adapt communication", "Respect beliefs"],
        completed: false,
      },
    ]
    setScenarios(mockScenarios)
  }, [])

  const filteredScenarios = scenarios.filter((scenario) => {
    const matchesSearch =
      scenario.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scenario.category.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesDifficulty = filterDifficulty === "all" || scenario.difficulty === filterDifficulty
    return matchesSearch && matchesDifficulty
  })

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "intermediate":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "advanced":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      default:
        return ""
    }
  }

  const handleStartPractice = (scenarioId: string) => {
    router.push(`/student/practice/${scenarioId}`)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Available Scenarios</CardTitle>
          <CardDescription>Choose a scenario to practice your communication skills</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6 flex flex-col gap-4 sm:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search scenarios..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={filterDifficulty === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterDifficulty("all")}
              >
                All
              </Button>
              <Button
                variant={filterDifficulty === "beginner" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterDifficulty("beginner")}
              >
                Beginner
              </Button>
              <Button
                variant={filterDifficulty === "intermediate" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterDifficulty("intermediate")}
              >
                Intermediate
              </Button>
              <Button
                variant={filterDifficulty === "advanced" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterDifficulty("advanced")}
              >
                Advanced
              </Button>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {filteredScenarios.map((scenario) => (
              <Card key={scenario.id} className="transition-shadow hover:shadow-md">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-lg">{scenario.title}</CardTitle>
                      <CardDescription>{scenario.category}</CardDescription>
                    </div>
                    <Badge className={getDifficultyColor(scenario.difficulty)}>{scenario.difficulty}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{scenario.description}</p>

                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{scenario.duration}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Target className="h-4 w-4" />
                      <span>{scenario.objectives.length} objectives</span>
                    </div>
                  </div>

                  {scenario.completed && scenario.lastScore && (
                    <div className="rounded-md bg-accent p-2 text-sm">
                      <span className="text-muted-foreground">Last score: </span>
                      <span className="font-semibold text-foreground">{scenario.lastScore}%</span>
                    </div>
                  )}

                  <Button className="w-full" onClick={() => handleStartPractice(scenario.id)}>
                    <Play className="mr-2 h-4 w-4" />
                    {scenario.completed ? "Practice Again" : "Start Practice"}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
