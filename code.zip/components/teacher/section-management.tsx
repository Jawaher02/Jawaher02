"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Users, Mail, Calendar } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface Section {
  id: string
  name: string
  studentCount: number
  createdDate: string
}

interface Student {
  id: string
  name: string
  email: string
  sectionId: string
  enrolledDate: string
  practiceCount: number
}

export function SectionManagement() {
  const [sections, setSections] = useState<Section[]>([])
  const [students, setStudents] = useState<Student[]>([])
  const [selectedSection, setSelectedSection] = useState<string | null>(null)
  const [isAddSectionOpen, setIsAddSectionOpen] = useState(false)
  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false)
  const [newSectionName, setNewSectionName] = useState("")
  const [newStudent, setNewStudent] = useState({ name: "", email: "" })

  useEffect(() => {
    // Load mock sections
    const mockSections: Section[] = [
      { id: "1", name: "Section A - Fall 2024", studentCount: 18, createdDate: "2024-09-01" },
      { id: "2", name: "Section B - Fall 2024", studentCount: 14, createdDate: "2024-09-01" },
    ]
    setSections(mockSections)

    // Load mock students
    const mockStudents: Student[] = [
      {
        id: "1",
        name: "John Smith",
        email: "john.s@med.edu",
        sectionId: "1",
        enrolledDate: "2024-09-05",
        practiceCount: 12,
      },
      {
        id: "2",
        name: "Emily Davis",
        email: "emily.d@med.edu",
        sectionId: "1",
        enrolledDate: "2024-09-05",
        practiceCount: 8,
      },
      {
        id: "3",
        name: "Michael Johnson",
        email: "michael.j@med.edu",
        sectionId: "1",
        enrolledDate: "2024-09-06",
        practiceCount: 15,
      },
      {
        id: "4",
        name: "Sarah Williams",
        email: "sarah.w@med.edu",
        sectionId: "2",
        enrolledDate: "2024-09-05",
        practiceCount: 10,
      },
    ]
    setStudents(mockStudents)
    setSelectedSection("1")
  }, [])

  const handleAddSection = () => {
    const section: Section = {
      id: Date.now().toString(),
      name: newSectionName,
      studentCount: 0,
      createdDate: new Date().toISOString().split("T")[0],
    }
    setSections([...sections, section])
    setIsAddSectionOpen(false)
    setNewSectionName("")
  }

  const handleAddStudent = () => {
    if (!selectedSection) return
    const student: Student = {
      id: Date.now().toString(),
      name: newStudent.name,
      email: newStudent.email,
      sectionId: selectedSection,
      enrolledDate: new Date().toISOString().split("T")[0],
      practiceCount: 0,
    }
    setStudents([...students, student])
    setSections(sections.map((s) => (s.id === selectedSection ? { ...s, studentCount: s.studentCount + 1 } : s)))
    setIsAddStudentOpen(false)
    setNewStudent({ name: "", email: "" })
  }

  const filteredStudents = students.filter((s) => s.sectionId === selectedSection)

  return (
    <div className="space-y-6">
      {/* Sections Overview */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>My Sections</CardTitle>
              <CardDescription>Manage your teaching sections</CardDescription>
            </div>
            <Dialog open={isAddSectionOpen} onOpenChange={setIsAddSectionOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Section
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Section</DialogTitle>
                  <DialogDescription>Add a new teaching section</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="sectionName">Section Name</Label>
                    <Input
                      id="sectionName"
                      value={newSectionName}
                      onChange={(e) => setNewSectionName(e.target.value)}
                      placeholder="e.g., Section C - Spring 2025"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddSectionOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddSection}>Create Section</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            {sections.map((section) => (
              <Card
                key={section.id}
                className={`cursor-pointer transition-colors ${
                  selectedSection === section.id ? "border-primary bg-accent" : "hover:bg-accent/50"
                }`}
                onClick={() => setSelectedSection(section.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <h3 className="font-semibold text-foreground">{section.name}</h3>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          <span>{section.studentCount} students</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          <span>{section.createdDate}</span>
                        </div>
                      </div>
                    </div>
                    {selectedSection === section.id && <Badge>Selected</Badge>}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Students in Selected Section */}
      {selectedSection && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Students</CardTitle>
                <CardDescription>{sections.find((s) => s.id === selectedSection)?.name}</CardDescription>
              </div>
              <Dialog open={isAddStudentOpen} onOpenChange={setIsAddStudentOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Student
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Student to Section</DialogTitle>
                    <DialogDescription>Enroll a new student in this section</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="studentName">Student Name</Label>
                      <Input
                        id="studentName"
                        value={newStudent.name}
                        onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                        placeholder="John Doe"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="studentEmail">Email</Label>
                      <Input
                        id="studentEmail"
                        type="email"
                        value={newStudent.email}
                        onChange={(e) => setNewStudent({ ...newStudent, email: e.target.value })}
                        placeholder="john@med.edu"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddStudentOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddStudent}>Add Student</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Enrolled Date</TableHead>
                    <TableHead>Practice Sessions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell className="font-medium">{student.name}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Mail className="h-3 w-3 text-muted-foreground" />
                          {student.email}
                        </div>
                      </TableCell>
                      <TableCell>{student.enrolledDate}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{student.practiceCount} sessions</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
