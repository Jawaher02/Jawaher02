"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, TrendingUp, TrendingDown, Minus } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"

interface StudentReport {
  id: string
  name: string
  section: string
  totalSessions: number
  avgScore: number
  lastPractice: string
  trend: "up" | "down" | "stable"
  strengths: string[]
  improvements: string[]
}

export function StudentReports() {
  const [reports, setReports] = useState<StudentReport[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedStudent, setSelectedStudent] = useState<StudentReport | null>(null)

  useEffect(() => {
    // Load mock reports
    const mockReports: StudentReport[] = [
      {
        id: "1",
        name: "John Smith",
        section: "Section A",
        totalSessions: 12,
        avgScore: 85,
        lastPractice: "2024-01-15",
        trend: "up",
        strengths: ["Empathy", "Active Listening", "Clear Communication"],
        improvements: ["Time Management", "Handling Difficult Questions"],
      },
      {
        id: "2",
        name: "Emily Davis",
        section: "Section A",
        totalSessions: 8,
        avgScore: 72,
        lastPractice: "2024-01-14",
        trend: "stable",
        strengths: ["Professional Demeanor", "Documentation"],
        improvements: ["Confidence", "Eye Contact", "Empathy Expression"],
      },
      {
        id: "3",
        name: "Michael Johnson",
        section: "Section A",
        totalSessions: 15,
        avgScore: 92,
        lastPractice: "2024-01-16",
        trend: "up",
        strengths: ["Empathy", "Clear Communication", "Patient Engagement", "Problem Solving"],
        improvements: ["Pacing"],
      },
      {
        id: "4",
        name: "Sarah Williams",
        section: "Section B",
        totalSessions: 10,
        avgScore: 78,
        lastPractice: "2024-01-13",
        trend: "down",
        strengths: ["Active Listening", "Professionalism"],
        improvements: ["Confidence", "Handling Emotions", "Follow-up Questions"],
      },
    ]
    setReports(mockReports)
  }, [])

  const filteredReports = reports.filter(
    (report) =>
      report.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.section.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return <TrendingUp className="h-4 w-4 text-green-600" />
      case "down":
        return <TrendingDown className="h-4 w-4 text-red-600" />
      default:
        return <Minus className="h-4 w-4 text-gray-600" />
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 85) return "text-green-600"
    if (score >= 70) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Student Performance Reports</CardTitle>
          <CardDescription>View detailed performance analytics for your students</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search students..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Section</TableHead>
                  <TableHead>Sessions</TableHead>
                  <TableHead>Avg. Score</TableHead>
                  <TableHead>Trend</TableHead>
                  <TableHead>Last Practice</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredReports.map((report) => (
                  <TableRow key={report.id}>
                    <TableCell className="font-medium">{report.name}</TableCell>
                    <TableCell>{report.section}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{report.totalSessions}</Badge>
                    </TableCell>
                    <TableCell>
                      <span className={`text-lg font-semibold ${getScoreColor(report.avgScore)}`}>
                        {report.avgScore}%
                      </span>
                    </TableCell>
                    <TableCell>{getTrendIcon(report.trend)}</TableCell>
                    <TableCell>{report.lastPractice}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm" onClick={() => setSelectedStudent(report)}>
                        View Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Report Modal */}
      {selectedStudent && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>{selectedStudent.name}</CardTitle>
                <CardDescription>Detailed Performance Report</CardDescription>
              </div>
              <Button variant="outline" onClick={() => setSelectedStudent(null)}>
                Close
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <h3 className="text-sm font-medium text-muted-foreground">Overall Performance</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Average Score</span>
                    <span className={`text-2xl font-bold ${getScoreColor(selectedStudent.avgScore)}`}>
                      {selectedStudent.avgScore}%
                    </span>
                  </div>
                  <Progress value={selectedStudent.avgScore} className="h-2" />
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium text-muted-foreground">Practice Activity</h3>
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Total Sessions:</span>
                    <span className="font-semibold">{selectedStudent.totalSessions}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Last Practice:</span>
                    <span className="font-semibold">{selectedStudent.lastPractice}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Trend:</span>
                    <span className="flex items-center gap-1">
                      {getTrendIcon(selectedStudent.trend)}
                      <span className="font-semibold capitalize">{selectedStudent.trend}</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-3">
                <h3 className="text-sm font-medium text-muted-foreground">Strengths</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedStudent.strengths.map((strength, index) => (
                    <Badge key={index} className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                      {strength}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-medium text-muted-foreground">Areas for Improvement</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedStudent.improvements.map((improvement, index) => (
                    <Badge
                      key={index}
                      className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                    >
                      {improvement}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
