"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Pencil, Trash2, Search } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface Scenario {
  id: string
  title: string
  category: string
  difficulty: "beginner" | "intermediate" | "advanced"
  description: string
  objectives: string[]
}

export function ScenarioManagement() {
  const [scenarios, setScenarios] = useState<Scenario[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newScenario, setNewScenario] = useState({
    title: "",
    category: "",
    difficulty: "beginner" as "beginner" | "intermediate" | "advanced",
    description: "",
    objectives: "",
  })

  useEffect(() => {
    // Load mock scenarios
    const mockScenarios: Scenario[] = [
      {
        id: "1",
        title: "Breaking Bad News",
        category: "Patient Communication",
        difficulty: "advanced",
        description: "Practice delivering difficult news to patients with empathy",
        objectives: ["Demonstrate empathy", "Use clear language", "Allow time for questions"],
      },
      {
        id: "2",
        title: "Taking Medical History",
        category: "Clinical Skills",
        difficulty: "beginner",
        description: "Conduct a comprehensive patient history interview",
        objectives: ["Ask open-ended questions", "Active listening", "Document accurately"],
      },
      {
        id: "3",
        title: "Informed Consent Discussion",
        category: "Ethics",
        difficulty: "intermediate",
        description: "Explain procedures and obtain informed consent",
        objectives: ["Explain risks and benefits", "Ensure understanding", "Respect autonomy"],
      },
    ]
    setScenarios(mockScenarios)
  }, [])

  const filteredScenarios = scenarios.filter(
    (scenario) =>
      scenario.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scenario.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleAddScenario = () => {
    const scenario: Scenario = {
      id: Date.now().toString(),
      title: newScenario.title,
      category: newScenario.category,
      difficulty: newScenario.difficulty,
      description: newScenario.description,
      objectives: newScenario.objectives.split("\n").filter((o) => o.trim()),
    }
    setScenarios([...scenarios, scenario])
    setIsAddDialogOpen(false)
    setNewScenario({ title: "", category: "", difficulty: "beginner", description: "", objectives: "" })
  }

  const handleDeleteScenario = (id: string) => {
    setScenarios(scenarios.filter((s) => s.id !== id))
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "intermediate":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "advanced":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      default:
        return ""
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Scenarios</CardTitle>
            <CardDescription>Manage practice scenarios for students</CardDescription>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Scenario
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Scenario</DialogTitle>
                <DialogDescription>Create a new practice scenario</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={newScenario.title}
                    onChange={(e) => setNewScenario({ ...newScenario, title: e.target.value })}
                    placeholder="Scenario title"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Input
                      id="category"
                      value={newScenario.category}
                      onChange={(e) => setNewScenario({ ...newScenario, category: e.target.value })}
                      placeholder="e.g., Patient Communication"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="difficulty">Difficulty</Label>
                    <Select
                      value={newScenario.difficulty}
                      onValueChange={(value: any) => setNewScenario({ ...newScenario, difficulty: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="beginner">Beginner</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newScenario.description}
                    onChange={(e) => setNewScenario({ ...newScenario, description: e.target.value })}
                    placeholder="Describe the scenario..."
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="objectives">Learning Objectives (one per line)</Label>
                  <Textarea
                    id="objectives"
                    value={newScenario.objectives}
                    onChange={(e) => setNewScenario({ ...newScenario, objectives: e.target.value })}
                    placeholder="Objective 1&#10;Objective 2&#10;Objective 3"
                    rows={4}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddScenario}>Add Scenario</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search scenarios..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Difficulty</TableHead>
                <TableHead>Description</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredScenarios.map((scenario) => (
                <TableRow key={scenario.id}>
                  <TableCell className="font-medium">{scenario.title}</TableCell>
                  <TableCell>{scenario.category}</TableCell>
                  <TableCell>
                    <Badge className={getDifficultyColor(scenario.difficulty)}>{scenario.difficulty}</Badge>
                  </TableCell>
                  <TableCell className="max-w-md truncate">{scenario.description}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="sm">
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => handleDeleteScenario(scenario.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
