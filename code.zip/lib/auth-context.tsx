"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type UserRole = "admin" | "teacher" | "student"

interface User {
  id: string
  email: string
  name: string
  role: UserRole
  sectionId?: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string, role: UserRole) => Promise<boolean>
  signup: (email: string, password: string, name: string, role: UserRole, sectionId?: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const storedUser = localStorage.getItem("medcomm_user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string, role: UserRole): Promise<boolean> => {
    // Mock authentication
    const users = JSON.parse(localStorage.getItem("medcomm_users") || "[]")
    const foundUser = users.find((u: User) => u.email === email && u.role === role)

    if (foundUser || (email === "admin@medcomm.ai" && role === "admin")) {
      const loggedInUser = foundUser || {
        id: "1",
        email: "admin@medcomm.ai",
        name: "Admin User",
        role: "admin",
      }
      setUser(loggedInUser)
      localStorage.setItem("medcomm_user", JSON.stringify(loggedInUser))
      return true
    }
    return false
  }

  const signup = async (
    email: string,
    password: string,
    name: string,
    role: UserRole,
    sectionId?: string,
  ): Promise<boolean> => {
    const users = JSON.parse(localStorage.getItem("medcomm_users") || "[]")
    const newUser: User = {
      id: Date.now().toString(),
      email,
      name,
      role,
      sectionId,
    }
    users.push(newUser)
    localStorage.setItem("medcomm_users", JSON.stringify(users))
    setUser(newUser)
    localStorage.setItem("medcomm_user", JSON.stringify(newUser))
    return true
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("medcomm_user")
  }

  return <AuthContext.Provider value={{ user, login, signup, logout, isLoading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
