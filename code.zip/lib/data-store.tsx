"use client"

// Mock data store for managing application data
// In production, this would connect to a real database

export interface User {
  id: string
  email: string
  name: string
  role: "admin" | "teacher" | "student"
  sectionId?: string
}

export interface Scenario {
  id: string
  title: string
  category: string
  difficulty: "beginner" | "intermediate" | "advanced"
  description: string
  objectives: string[]
}

export interface PracticeSession {
  id: string
  studentId: string
  scenarioId: string
  date: string
  duration: number
  overallScore: number
  skillScores: {
    skill: string
    score: number
  }[]
  strengths: string[]
  improvements: string[]
}

export interface StudentProgress {
  studentId: string
  totalSessions: number
  avgScore: number
  skillProgress: {
    skill: string
    score: number
    sessions: number
    trend: "up" | "down" | "stable"
  }[]
  completedScenarios: string[]
}

// Initialize default data
const initializeData = () => {
  if (typeof window === "undefined") return

  // Initialize scenarios if not exists
  if (!localStorage.getItem("medcomm_scenarios")) {
    const defaultScenarios: Scenario[] = [
      {
        id: "1",
        title: "Breaking Bad News",
        category: "Patient Communication",
        difficulty: "advanced",
        description: "Practice delivering difficult news to patients with empathy",
        objectives: ["Demonstrate empathy", "Use clear language", "Allow time for questions"],
      },
      {
        id: "2",
        title: "Taking Medical History",
        category: "Clinical Skills",
        difficulty: "beginner",
        description: "Conduct a comprehensive patient history interview",
        objectives: ["Ask open-ended questions", "Active listening", "Document accurately"],
      },
      {
        id: "3",
        title: "Informed Consent Discussion",
        category: "Ethics",
        difficulty: "intermediate",
        description: "Explain procedures and obtain informed consent",
        objectives: ["Explain risks and benefits", "Ensure understanding", "Respect autonomy"],
      },
    ]
    localStorage.setItem("medcomm_scenarios", JSON.stringify(defaultScenarios))
  }

  // Initialize practice sessions if not exists
  if (!localStorage.getItem("medcomm_sessions")) {
    localStorage.setItem("medcomm_sessions", JSON.stringify([]))
  }
}

export const DataStore = {
  // Practice Sessions
  savePracticeSession: (session: PracticeSession) => {
    initializeData()
    const sessions = JSON.parse(localStorage.getItem("medcomm_sessions") || "[]")
    sessions.push(session)
    localStorage.setItem("medcomm_sessions", JSON.stringify(sessions))
  },

  getPracticeSessionsByStudent: (studentId: string): PracticeSession[] => {
    initializeData()
    const sessions = JSON.parse(localStorage.getItem("medcomm_sessions") || "[]")
    return sessions.filter((s: PracticeSession) => s.studentId === studentId)
  },

  getAllPracticeSessions: (): PracticeSession[] => {
    initializeData()
    return JSON.parse(localStorage.getItem("medcomm_sessions") || "[]")
  },

  // Student Progress
  calculateStudentProgress: (studentId: string): StudentProgress => {
    const sessions = DataStore.getPracticeSessionsByStudent(studentId)

    if (sessions.length === 0) {
      return {
        studentId,
        totalSessions: 0,
        avgScore: 0,
        skillProgress: [],
        completedScenarios: [],
      }
    }

    // Calculate average score
    const avgScore = Math.round(sessions.reduce((sum, s) => sum + s.overallScore, 0) / sessions.length)

    // Calculate skill progress
    const skillMap = new Map<string, { total: number; count: number; scores: number[] }>()

    sessions.forEach((session) => {
      session.skillScores.forEach((skill) => {
        if (!skillMap.has(skill.skill)) {
          skillMap.set(skill.skill, { total: 0, count: 0, scores: [] })
        }
        const data = skillMap.get(skill.skill)!
        data.total += skill.score
        data.count += 1
        data.scores.push(skill.score)
      })
    })

    const skillProgress = Array.from(skillMap.entries()).map(([skill, data]) => {
      const avgSkillScore = Math.round(data.total / data.count)

      // Calculate trend
      let trend: "up" | "down" | "stable" = "stable"
      if (data.scores.length >= 2) {
        const recent = data.scores.slice(-3)
        const older = data.scores.slice(0, -3)
        if (older.length > 0) {
          const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length
          const olderAvg = older.reduce((a, b) => a + b, 0) / older.length
          if (recentAvg > olderAvg + 5) trend = "up"
          else if (recentAvg < olderAvg - 5) trend = "down"
        }
      }

      return {
        skill,
        score: avgSkillScore,
        sessions: data.count,
        trend,
      }
    })

    // Get completed scenarios
    const completedScenarios = [...new Set(sessions.map((s) => s.scenarioId))]

    return {
      studentId,
      totalSessions: sessions.length,
      avgScore,
      skillProgress,
      completedScenarios,
    }
  },

  // Scenarios
  getScenarios: (): Scenario[] => {
    initializeData()
    return JSON.parse(localStorage.getItem("medcomm_scenarios") || "[]")
  },

  getScenarioById: (id: string): Scenario | null => {
    const scenarios = DataStore.getScenarios()
    return scenarios.find((s) => s.id === id) || null
  },

  // Analytics for Teachers
  getSectionAnalytics: (sectionId: string) => {
    const users = JSON.parse(localStorage.getItem("medcomm_users") || "[]")
    const students = users.filter((u: User) => u.role === "student" && u.sectionId === sectionId)

    const analytics = students.map((student: User) => {
      const progress = DataStore.calculateStudentProgress(student.id)
      const sessions = DataStore.getPracticeSessionsByStudent(student.id)
      const lastSession = sessions.length > 0 ? sessions[sessions.length - 1] : null

      return {
        studentId: student.id,
        studentName: student.name,
        totalSessions: progress.totalSessions,
        avgScore: progress.avgScore,
        lastPractice: lastSession?.date || "Never",
        trend: progress.avgScore > 80 ? "up" : progress.avgScore > 60 ? "stable" : "down",
        strengths: lastSession?.strengths || [],
        improvements: lastSession?.improvements || [],
      }
    })

    return analytics
  },
}

// Initialize data on module load
if (typeof window !== "undefined") {
  initializeData()
}
